import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import {
  getAuth, onAuthStateChanged, signInWithEmailAndPassword,
  createUserWithEmailAndPassword, sendPasswordResetEmail, signOut
} from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import {
  getFirestore, collection, query, where, orderBy, limit, onSnapshot,
  doc, getDoc, getDocs, addDoc, serverTimestamp, httpsCallable, Timestamp
} from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";
import { getFunctions } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-functions.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const functions = getFunctions(app, "asia-south1");
const $ = (id) => document.getElementById(id);
const money = n => new Intl.NumberFormat("en-BD", {style:"currency",currency:"BDT",maximumFractionDigits:0}).format(n);
let currentUser = null, isAdmin = false, packages = [], selected = null, stopMyOrders = null, stopAdminOrders = null, toastTimer;

$("year").textContent = new Date().getFullYear();
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),3200)}
function authModal(open){$("authModal").classList.toggle("hidden",!open);$("authMessage").textContent="";$("authMessage").className="message"}
$("loginOpen").onclick=()=>authModal(true);$("accountLogin").onclick=()=>authModal(true);$("authClose").onclick=()=>authModal(false);
$("authModal").addEventListener("click",e=>{if(e.target===$("authModal"))authModal(false)});
$("logoutBtn").onclick=async()=>{try{await signOut(auth);toast("লগআউট হয়েছে")}catch(e){toast(friendlyError(e))}};

function friendlyError(e){
  const map={"auth/invalid-credential":"ইমেইল বা পাসওয়ার্ড সঠিক নয়।","auth/email-already-in-use":"এই ইমেইলে অ্যাকাউন্ট আছে।","auth/weak-password":"আরও শক্তিশালী পাসওয়ার্ড দিন।","auth/invalid-email":"সঠিক ইমেইল লিখুন।","auth/too-many-requests":"অনেকবার চেষ্টা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন.","permission-denied":"এই কাজের অনুমতি নেই।"};
  return map[e.code] || e.message || "কিছু সমস্যা হয়েছে।";
}
$("authForm").onsubmit=async e=>{e.preventDefault();$("authMessage").textContent="লগইন হচ্ছে…";try{await signInWithEmailAndPassword(auth,$("email").value.trim(),$("password").value);authModal(false);toast("লগইন সফল")}catch(err){$("authMessage").textContent=friendlyError(err);$("authMessage").className="message error"}};
$("registerBtn").onclick=async()=>{if(!$("authForm").reportValidity())return;$("authMessage").textContent="অ্যাকাউন্ট তৈরি হচ্ছে…";try{await createUserWithEmailAndPassword(auth,$("email").value.trim(),$("password").value);authModal(false);toast("অ্যাকাউন্ট তৈরি হয়েছে")}catch(err){$("authMessage").textContent=friendlyError(err);$("authMessage").className="message error"}};
$("resetBtn").onclick=async()=>{const email=$("email").value.trim();if(!email){$("authMessage").textContent="আগে ইমেইল লিখুন।";return}try{await sendPasswordResetEmail(auth,email);$("authMessage").textContent="পাসওয়ার্ড রিসেট ইমেইল পাঠানো হয়েছে।";$("authMessage").className="message success"}catch(e){$("authMessage").textContent=friendlyError(e);$("authMessage").className="message error"}};

function renderPackages(){
 const wrap=$("packages");wrap.innerHTML="";
 if(!packages.length){wrap.innerHTML='<p class="muted">এখন কোনো প্যাকেজ নেই। Admin Firestore-এ packages যোগ করুন।</p>';return}
 packages.forEach(p=>{const b=document.createElement("button");b.type="button";b.className="package"+(selected?.id===p.id?" selected":"");b.innerHTML=`<span class="gem">◆</span><b></b><small>Free Fire Diamonds</small><strong></strong>`;b.querySelector("b").textContent=p.name;b.querySelector("strong").textContent=money(p.price);b.onclick=()=>{selected=p;renderPackages();updateSelection()};wrap.appendChild(b)});
}
function updateSelection(){$("selectedName").textContent=selected?.name||"কোনো প্যাকেজ নয়";$("selectedPrice").textContent=money(selected?.price||0);$("orderBtn").disabled=!currentUser||!selected;$("orderBtn").innerHTML=currentUser?'অর্ডার সাবমিট করুন <span>→</span>':'Login করে অর্ডার দিন <span>→</span>'}
async function loadPackages(){
 try{const snap=await getDocs(query(collection(db,"packages"),where("active","==",true),orderBy("sortOrder")));packages=snap.docs.map(d=>({id:d.id,...d.data()})).filter(p=>typeof p.name==="string"&&Number.isFinite(p.price)&&p.price>0);renderPackages();updateSelection()}
 catch(e){$("packages").innerHTML='<p class="muted">প্যাকেজ লোড হয়নি। Firestore rules ও packages ডেটা পরীক্ষা করুন।</p>';console.error(e)}
}
function orderCard(o,admin=false){
 const div=document.createElement("div");div.className="order-item";
 const top=document.createElement("div");top.className="order-top";
 const title=document.createElement("span");title.textContent=`${o.packageName||"Diamond package"} · ${money(o.price||0)}`;
 const status=document.createElement("span");status.className="status "+(o.status||"pending");status.textContent=(o.status||"pending").toUpperCase();top.append(title,status);div.append(top);
 const meta=document.createElement("div");meta.className="order-meta";meta.textContent=`UID: ${o.playerUid||"—"} · Order: ${(o.id||"").slice(0,8)} · ${o.createdAt?.toDate?o.createdAt.toDate().toLocaleString("bn-BD"):"Just now"}`;div.append(meta);
 if(admin){const row=document.createElement("div");row.className="admin-row";const select=document.createElement("select");["pending","processing","completed","cancelled"].forEach(s=>{const op=document.createElement("option");op.value=s;op.textContent=s;op.selected=s===(o.status||"pending");select.append(op)});const btn=document.createElement("button");btn.className="btn btn-primary";btn.textContent="Update";btn.onclick=async()=>{btn.disabled=true;try{const updateOrder=httpsCallable(functions,"adminUpdateOrder");await updateOrder({orderId:o.id,status:select.value});toast("অর্ডার আপডেট হয়েছে")}catch(e){toast(friendlyError(e))}finally{btn.disabled=false}};row.append(select,btn);div.append(row)}
 return div;
}
function watchMyOrders(user){
 if(stopMyOrders)stopMyOrders();
 const q=query(collection(db,"orders"),where("userId","==",user.uid),orderBy("createdAt","desc"),limit(20));
 stopMyOrders=onSnapshot(q,s=>{const wrap=$("myOrders");wrap.innerHTML="";if(s.empty){wrap.innerHTML='<p class="muted">এখনো কোনো অর্ডার নেই।</p>';return}s.forEach(d=>wrap.append(orderCard({id:d.id,...d.data()})))},e=>{$("myOrders").textContent=friendlyError(e)});
}
function watchAdminOrders(){
 if(stopAdminOrders)stopAdminOrders();
 const q=query(collection(db,"orders"),orderBy("createdAt","desc"),limit(50));
 stopAdminOrders=onSnapshot(q,s=>{const wrap=$("adminOrders");wrap.innerHTML="";if(s.empty){wrap.innerHTML='<p class="muted">অর্ডার নেই।</p>';return}s.forEach(d=>wrap.append(orderCard({id:d.id,...d.data()},true)))},e=>{$("adminOrders").textContent=friendlyError(e)});
}
onAuthStateChanged(auth,async user=>{
 currentUser=user;isAdmin=false;
 $("loginOpen").classList.toggle("hidden",!!user);$("logoutBtn").classList.toggle("hidden",!user);
 $("accountStatus").querySelector("span:last-child").textContent=user?"লগইন করা আছে":"আপনি লগইন করেননি";
 $("accountStatus").querySelector(".status-dot").classList.toggle("online",!!user);
 $("accountEmail").textContent=user?.email||"অর্ডার দিতে ইমেইল দিয়ে লগইন করুন।";
 if(stopMyOrders){stopMyOrders();stopMyOrders=null}if(stopAdminOrders){stopAdminOrders();stopAdminOrders=null}
 if(user){
   watchMyOrders(user);
   try{const token=await user.getIdTokenResult(true);isAdmin=token.claims.admin===true}catch(e){console.warn(e)}
   $("adminPanel").classList.toggle("hidden",!isAdmin);if(isAdmin)watchAdminOrders();
 }else{$("adminPanel").classList.add("hidden");$("myOrders").innerHTML='<p class="muted">লগইন করলে অর্ডার এখানে দেখা যাবে।</p>'}
 updateSelection();
});
$("orderBtn").onclick=async()=>{
 if(!currentUser){authModal(true);return}
 const uid=$("playerUid").value.trim();
 if(!/^\d{6,24}$/.test(uid)){toast("সঠিক Player UID লিখুন (৬–২৪টি সংখ্যা)");$("playerUid").focus();return}
 if(!selected){toast("একটি প্যাকেজ বেছে নিন");return}
 $("orderBtn").disabled=true;
 try{
   // Callable Cloud Function server-side price/package validation করে order তৈরি করে।
   const createOrder=httpsCallable(functions,"createTopupOrder");
   const result=await createOrder({playerUid:uid,packageId:selected.id});
   toast("অর্ডার তৈরি হয়েছে: "+result.data.orderId.slice(0,8));
 }catch(e){toast(friendlyError(e))}
 finally{updateSelection()}
};
$("playerUid").addEventListener("input",()=>{$("playerUid").value=$("playerUid").value.replace(/\D/g,"").slice(0,24)});
loadPackages();

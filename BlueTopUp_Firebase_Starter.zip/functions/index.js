const {onCall, HttpsError} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore, FieldValue} = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();

function requireUser(request) {
  if (!request.auth) throw new HttpsError("unauthenticated", "প্রথমে লগইন করুন।");
}
function requireAdmin(request) {
  requireUser(request);
  if (request.auth.token.admin !== true) throw new HttpsError("permission-denied", "Admin permission required.");
}

// Server validates the current package and price; client cannot set the price/status/userId.
exports.createTopupOrder = onCall({region:"asia-south1", enforceAppCheck:true}, async (request) => {
  requireUser(request);
  const uid = String(request.data?.playerUid || "").trim();
  const packageId = String(request.data?.packageId || "").trim();
  if (!/^\d{6,24}$/.test(uid)) throw new HttpsError("invalid-argument", "সঠিক Player UID দিন।");
  if (!/^[A-Za-z0-9_-]{1,128}$/.test(packageId)) throw new HttpsError("invalid-argument", "প্যাকেজ নির্বাচন করুন।");

  const packageRef = db.collection("packages").doc(packageId);
  const packageSnap = await packageRef.get();
  if (!packageSnap.exists || packageSnap.data().active !== true) {
    throw new HttpsError("failed-precondition", "এই প্যাকেজটি এখন পাওয়া যাচ্ছে না।");
  }
  const p = packageSnap.data();
  if (typeof p.name !== "string" || !Number.isFinite(p.price) || p.price <= 0) {
    throw new HttpsError("failed-precondition", "প্যাকেজের তথ্য সঠিক নয়।");
  }

  const ref = await db.collection("orders").add({
    userId: request.auth.uid,
    userEmail: request.auth.token.email || null,
    playerUid: uid,
    packageId: packageSnap.id,
    packageName: p.name,
    price: p.price,
    status: "pending",
    paymentStatus: "unpaid",
    fulfillmentStatus: "not_started",
    createdAt: FieldValue.serverTimestamp()
  });
  return {orderId: ref.id, status:"pending"};
});

// Only a user with a server-assigned custom claim {admin:true} can update status.
exports.adminUpdateOrder = onCall({region:"asia-south1", enforceAppCheck:true}, async (request) => {
  requireAdmin(request);
  const orderId = String(request.data?.orderId || "");
  const status = String(request.data?.status || "");
  if (!/^[A-Za-z0-9_-]{10,128}$/.test(orderId)) throw new HttpsError("invalid-argument", "Order ID invalid.");
  if (!["pending","processing","completed","cancelled"].includes(status)) {
    throw new HttpsError("invalid-argument", "Status invalid.");
  }
  const ref = db.collection("orders").doc(orderId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "Order not found.");
  await ref.update({status, updatedAt:FieldValue.serverTimestamp(), updatedBy:request.auth.uid});
  return {ok:true};
});


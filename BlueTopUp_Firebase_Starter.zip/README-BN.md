# BlueTopUp — Free Fire UID Top-up starter

নীল-সাদা responsive storefront; Firebase Email/Password Authentication; Firestore package list; customer-only order history; custom-claim protected admin order panel; Cloud Functions দিয়ে server-side order creation/status update।

## 1. Firebase project তৈরি

1. https://console.firebase.google.com/ এ project তৈরি করুন।
2. Authentication → Sign-in method → Email/Password চালু করুন।
3. Firestore Database তৈরি করুন।
4. Project settings → Your apps → Web app যোগ করে config কপি করুন।
5. `public/firebase-config.js`-এ নিজের `apiKey`, `authDomain`, `projectId`, `appId` বসান। এই web config public identifier—কিন্তু Security Rules-ই ডেটা সুরক্ষিত করে; service-account key কখনো public folder-এ দেবেন না।

## 2. Firestore-এ packages যোগ করুন

`packages` collection-এ প্রতিটি document-এ এই fields দিন (price number হিসেবে):

```json
{
  "name": "100 Diamonds",
  "price": 99,
  "active": true,
  "sortOrder": 1
}
```

উদাহরণের দাম কেবল placeholder—নিজের বৈধ supplier price ও ব্যবসার খরচ অনুযায়ী সেট করুন। UI থেকে package edit করা যায় না; trusted Firebase Console/Admin SDK দিয়ে পরিবর্তন করুন।

## 3. Deploy

Node.js 20 এবং Firebase CLI ইনস্টল করে project root-এ:

```bash
npm install -g firebase-tools
firebase login
firebase use --add
cd functions && npm install && cd ..
firebase deploy --only firestore:rules,functions,hosting
```

Firebase Console থেকে App Check configure করুন। Cloud Functions deploy করতে billing-enabled Firebase/Google Cloud project লাগতে পারে।

## 4. প্রথম admin সেট করুন (নিরাপদ পদ্ধতি)

Admin status browser-এ `loggedIn: true` লিখে চালু করবেন না। এই project-এ `admin` custom claim server-side যাচাই করা হয়। আপনার প্রথম admin-এর Firebase Authentication UID নিন। নিরাপদ, private admin workstation-এ Firebase Admin SDK initialize করে একবার চালান:

```js
const { initializeApp, applicationDefault } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
initializeApp({ credential: applicationDefault(), projectId: "YOUR_PROJECT_ID" });
getAuth().setCustomUserClaims("YOUR_AUTH_USER_UID", { admin: true });
```

এটি `set-admin.js`-এ রেখে secure admin workstation-এ Application Default Credentials দিয়ে চালানো যায়। Service-account JSON কখনো GitHub বা website-এ commit করবেন না। Claim সেট হওয়ার পর admin-কে sign out/in করতে হবে বা ID token refresh করতে হবে। Admin access সরাতে `{admin:false}` সেট করুন। Admin UID কাউকে প্রকাশ করবেন না।

## 5. বাস্তব payment ও diamond delivery

এই template **অর্ডার রেকর্ড তৈরি করে**, কিন্তু নিজে টাকা নেয় না এবং diamonds deliver করে না। Production চালুর আগে:
- বৈধ Garena/Free Fire top-up supplier-এর অনুমোদিত API বা merchant arrangement যুক্ত করুন।
- bKash/Nagad/payment gateway-এর official merchant API server-side integrate করুন।
- payment provider-এর signed webhook server-এ verify করুন; browser-এর success message দেখে order paid করবেন না।
- সফল payment যাচাই হওয়ার পরই idempotent fulfillment job চালান। Supplier API key শুধু Cloud Functions Secret Manager-এ রাখুন।
- refund, duplicate webhook, retry, fraud/abuse, rate limits, audit logs, monitoring এবং support policy যোগ করুন।

## Security notes

- `isLoggedIn=true` বা client-side role check আসল authentication নয়।
- Firestore rules customer-কে শুধু নিজের order পড়তে দেয়; browser থেকে order create/update বন্ধ।
- Callable function signed-in UID থেকে userId নেয় এবং server-side package price পড়ে।
- Admin custom claim শুধুমাত্র trusted Admin SDK দিয়ে সেট হবে।
- `enforceAppCheck: true` হওয়ায় deploy করার পর Firebase App Check সঠিকভাবে configure করুন।
- এই starter production payment/delivery system নয়; launch করার আগে test project-এ end-to-end security review করুন।
